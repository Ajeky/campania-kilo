export interface Historia {
    titulo: string;
    descripcion: string;
    estado: string;
}