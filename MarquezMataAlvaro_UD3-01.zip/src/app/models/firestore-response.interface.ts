export interface FirestoreResponse<T>{
    id: string;
    data: T;
}